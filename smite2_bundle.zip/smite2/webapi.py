"""JSON entry points for the browser build calculator (web/), run in Pyodide.

Every function takes and returns plain dicts so the page can call it with a JSON payload.
"""
import argparse

from .cli import _aspect_note, _build_dict, _context, is_farm_stacking
from .data import Database
from .explain import explain as _explain
from .optimizer import Constraints, optimize, suggest_relics

_DB = None
# gods whose kits heal allies or themselves heavily (enemy pick -> anti-heal); merged with kit utility tags
HEALERS = {"Aphrodite", "Baron Samedi", "Chang'e", "Guan Yu", "Hel", "Horus", "Ix Chel", "Princess Bari", "Ra",
           "Sylvanus", "Yemoja", "Kali", "Artio", "Bacchus"}


# What an enemy's Aspect changes for itemizing against them (from the aspect texts in data/aspects.json):
# damage type (share of physical) and whether they heal allies.
ENEMY_ASPECT = {
    "Izanami": {"phys": 0.5, "why": "Sickle Storm adds magical damage"},
    "Aphrodite": {"healer": False, "why": "Heartbreak can no longer link to allies, so no ally healing"},
    "Eset": {"healer": True, "why": "Lifewarden shields and heals allies"},
    "Nut": {"healer": True, "why": "Cosmic Flux heals allies"},
}


def db() -> Database:
    global _DB
    if _DB is None:
        _DB = Database()
    return _DB


def meta() -> dict:
    d = db()
    gods = sorted(d.gods.values(), key=lambda g: g.name)
    return {
        "gods": [{"name": g.name, "roles": g.roles, "damage_type": g.damage_type, "range": g.attack_range,
                  "aspect": (d.aspects.get(g.name) or {}).get("name") if (d.aspects.get(g.name) or {}).get("released") else None,
                  "aspect_model": g.name in d.aspect_models,
                  "healer": _is_healer(g), "aspect_effect": ENEMY_ASPECT.get(g.name)}
                 for g in gods],
        "items": sorted(i.name for i in d.tier3()),
        "starters": sorted(i.name for i in d.starters()),
        "data_checked": d.mechanics.get("_meta", {}).get("audit", {}).get("checked"),
    }


def _is_healer(g) -> bool:
    return g.name in HEALERS or bool({"team_sustain"} & set(g.builtin_utility))


def _args(p: dict) -> argparse.Namespace:
    """Same options as the CLI; enemy gods (if given) set the damage split and healing flag."""
    d = db()
    enemies = [d.god(n) for n in p.get("enemies", []) if n]
    on_aspect = {d.god(n).name for n in p.get("enemy_aspects", []) if n}

    def enemy_phys(e):
        if e.name in on_aspect and "phys" in ENEMY_ASPECT.get(e.name, {}):
            return ENEMY_ASPECT[e.name]["phys"]
        return 1.0 if e.damage_type == "physical" else 0.0

    def enemy_heals(e):
        if e.name in on_aspect and "healer" in ENEMY_ASPECT.get(e.name, {}):
            return ENEMY_ASPECT[e.name]["healer"]
        return _is_healer(e)

    phys = p.get("enemy_physical")
    if enemies and phys is None:
        phys = sum(map(enemy_phys, enemies)) / len(enemies)
    healing = p.get("enemy_healing")
    if healing is None:
        healing = any(map(enemy_heals, enemies))
    return argparse.Namespace(
        mode=p.get("mode", "auto"), role=p.get("role") or None, target=p.get("target") or None,
        stacks=p.get("stacks", "even"), map=p.get("map", "conquest"),
        enemy_physical=0.5 if phys is None else float(phys), enemy_healing=bool(healing),
        enemy_cc_heavy=bool(p.get("enemy_cc_heavy", False)), aspect=bool(p.get("aspect", False)),
        scaling=p.get("scaling") or "auto")


def _god(p: dict):
    d = db()
    g = d.god(p["god"])
    return d.with_aspect(g) if p.get("aspect") and g.name in d.aspect_models else g


def build(p: dict) -> dict:
    d, god = db(), _god(p)
    a = _args(p)
    ctx = _context(d, god, a)
    cons = Constraints(require=[d.item(n) for n in p.get("require", []) if n],
                       exclude=set(p.get("exclude", [])),
                       starter=d.item(p["starter"]) if p.get("starter") else None,
                       budget=p.get("budget") or None, min_defense=int(p.get("min_defense", 0)))
    builds, scorer = optimize(d, god, ctx, cons, beam_width=int(p.get("beam", 50)), top=int(p.get("top", 2)))
    out = []
    for b in builds:
        r = _build_dict(scorer, b, d)
        r["costs"] = {i.name: i.cost for i in b.all_items}
        r["stacking_first"] = [i.name for i in b.items if is_farm_stacking(i)]
        r["utility"] = sorted(b.evaluation.utility)
        r["pro"] = {i.name: d.meta_tiers[i.name] for i in b.all_items if i.name in d.meta_tiers}
        out.append(r)
    a_full = d.aspects.get(god.name) or {}
    has_aspect_data = f"{god.name}|{ctx.role or god.roles[0]}" in d.community.get("aspects", {})
    if god.aspect:
        aspect_text = f"Built for {god.aspect}: aspect kit model plus top players' aspect builds."
    elif ctx.aspect and a_full.get("name"):
        aspect_text = (f"Built for {a_full['name']} from top players' recent aspect games." if has_aspect_data
                       else f"{a_full['name']}: no aspect game data yet for this role, so this is the base-kit build.")
    elif a_full.get("name"):
        aspect_text = f"Base kit (aspect off). Tick Aspect to build for {a_full['name']}."
    else:
        aspect_text = ""
    return {"god": god.name, "class": god.god_class, "role": ctx.role or god.roles[0], "mode": ctx.mode,
            "map": a.map, "aspect_text": aspect_text,
            "target": ctx.target, "enemy_physical": round(ctx.enemy_physical_share, 2),
            "enemy_healing": ctx.enemy_healing, "aspect": _aspect_note(d, god.name, god.aspect),
            "description": god.kit.get("description", ""), "builds": out,
            "relics": [r["name"] + " - " + r.get("description", "") for r in suggest_relics(d, god, ctx)]}


def explain(p: dict) -> dict:
    d, god = db(), _god(p)
    return _explain(d, god, d.item(p["item"]), _context(d, god, _args(p)), beam=int(p.get("beam", 40)))


def evaluate(p: dict) -> dict:
    """Score a build the user typed in (kept in their order) and compare it with the forged one."""
    from .model import Scorer
    from .optimizer import Build
    d, god = db(), _god(p)
    ctx = _context(d, god, _args(p))
    names = [n for n in p.get("items", []) if n]
    problems = []
    for n in names + ([p["starter_item"]] if p.get("starter_item") else []):
        try:
            d.item(n)
        except KeyError as e:
            problems.append(str(e.args[0]))
    if problems:
        raise ValueError(" ".join(problems))
    items = [d.item(n) for n in names]
    if len({i.name for i in items}) < len(items):
        raise ValueError("The same item is in two slots. Each item can only be bought once.")
    if any(i.tier == "starter" for i in items):
        raise ValueError("Starters go in the starter slot, not an item slot.")
    starter = d.item(p["starter_item"]) if p.get("starter_item") else None
    if starter is not None and starter.tier != "starter":
        raise ValueError(f"{starter.name} is not a starter.")
    scorer = Scorer(d, god, ctx)
    ev = scorer([*([starter] if starter else []), *items])
    r = _build_dict(scorer, Build(starter, items, ev), d)
    r["costs"] = {i.name: i.cost for i in items + ([starter] if starter else [])}
    r["pro"] = {i.name: d.meta_tiers[i.name] for i in items if i.name in d.meta_tiers}
    actives = sum(i.active for i in items + ([starter] if starter else []))
    r["warnings"] = ([f"{actives} active items: SMITE 2 allows at most 3."] if actives > 3 else [])
    return r

