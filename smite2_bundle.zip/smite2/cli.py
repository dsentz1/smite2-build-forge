"""Command line: python -m smite2 <command> ..."""

from __future__ import annotations

import argparse
import json
import sys

from .data import MODES, ROLES, Database
from dataclasses import replace

from .model import default_mode_for, Context, Scorer
from .optimizer import (Build, Constraints, best_replacements, buy_order, contributions,
                        optimize, suggest_relics, is_farm_stacking, buy_reason)

KEY_STATS = [
    ("strength", "Strength", "{:.0f}"), ("intelligence", "Intelligence", "{:.0f}"),
    ("attack_speed_total", "Attack speed", "{:.2f}/s"), ("crit_chance", "Crit chance", "{:.0%}"),
    ("penetration", "Penetration", "{:.0%}"), ("cooldown_reduction", "Cooldown reduction", "{:.0%}"),
    ("lifesteal", "Lifesteal", "{:.0%}"), ("max_health", "Health", "{:.0f}"),
    ("max_mana", "Mana", "{:.0f}"), ("physical_protection", "Phys prot", "{:.0f}"),
    ("magical_protection", "Mag prot", "{:.0f}"), ("plating", "Plating", "{:.0f}"), ("dampening", "Dampening", "{:.0f}"),
    ("echo", "Echo", "{:.0f}"),
]


def _add_context_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--mode", choices=sorted(MODES | {"auto"}), default="auto",
                   help="what to optimize; auto = the god's archetype default")
    p.add_argument("--role", choices=sorted(ROLES), help="role (default: god's primary role)")
    p.add_argument("--target", choices=["squishy", "bruiser", "tank"], default=None,
                   help="who you are trying to kill (default: squishy; bruiser in Assault)")
    p.add_argument("--stacks", choices=["behind", "even", "ahead"], default="even",
                   help="snowball scenario for kill/farm-stacking items; 'ahead' = fully stacked (max potential)")
    p.add_argument("--map", choices=["conquest", "assault", "joust"], default="conquest",
                   help="assault: no fountain healing, shop only on death -> sustain valued over a longer window; "
                        "joust: 3v3 single lane, cramped fights -> aura items valued for every role")
    p.add_argument("--enemy-physical", type=float, default=0.5, metavar="SHARE",
                   help="share of enemy damage that is physical, 0-1 (default 0.5)")
    p.add_argument("--enemy-healing", action="store_true", help="enemy has heavy healing (wants anti-heal)")
    p.add_argument("--counter-cc", "--enemy-cc-heavy", dest="enemy_cc_heavy", action="store_true",
                   help="counter crowd control: favor CC immunity, tenacity, displacement/slow immunity, Purification Beads")
    p.add_argument("--json", action="store_true", help="machine-readable output")
    p.add_argument("--scaling", choices=["auto", "strength", "intelligence"], default="auto",
                   help="force the main stat (off-stat builds such as Strength Agni or Intelligence Xbalanque)")
    p.add_argument("--aspect", action="store_true", help="the player is on the god's Aspect: uses top players' aspect builds (and the aspect kit model where one exists)")


def _context(db: Database, god, args) -> Context:
    mode = default_mode_for(god, args.role) if args.mode == "auto" else args.mode
    gm = db.mechanics.get("game_modes", {}).get(args.map, {})
    return Context(mode=mode, target=args.target or gm.get("default_target", "squishy"), role=args.role,
                   game_mode=args.map, sustain_window=gm.get("sustain_window_seconds"), stacks=args.stacks,
                   aura_bonus=gm.get("aura_bonus", 0.0), aspect=bool(getattr(args, "aspect", False)),
                   scaling=getattr(args, "scaling", "auto"),
                   enemy_physical_share=args.enemy_physical,
                   enemy_healing=args.enemy_healing, enemy_cc_heavy=args.enemy_cc_heavy)


def scenario_table(db: Database, god, ctx: Context, build: Build) -> dict:
    """Burst/DPS/EHP of a build with snowball items behind, even and fully stacked."""
    out = {}
    for level in ("behind", "even", "ahead"):
        ev = Scorer(db, god, replace(ctx, stacks=level))(build.all_items)
        out[level] = {"score": round(ev.score, 3), "burst": round(ev.burst), "dps": round(ev.dps), "ehp": round(ev.ehp)}
    return out


def snowball_items(build: Build) -> list[str]:
    return [i.name for i in build.all_items if any(e.get("snowball") for e in i.effects)]


def _build_dict(scorer: Scorer, build: Build, db: Database) -> dict:
    ev, base = build.evaluation, scorer.baseline
    return {
        "starter": build.starter.name if build.starter else None,
        "items": [i.name for i in build.items],
        "buy_notes": {i.name: buy_reason(i) for i in build.items if buy_reason(i)},
        "total_cost": build.cost,
        "score": round(ev.score, 4),
        "metrics": {
            "burst": round(ev.burst), "dps": round(ev.dps), "ehp": round(ev.ehp),
            "burst_x_baseline": round(ev.burst / base.burst, 2),
            "dps_x_baseline": round(ev.dps / base.dps, 2),
            "ehp_x_baseline": round(ev.ehp / base.ehp, 2),
        },
        "stats": {k: round(ev.stats.get(k, 0), 3) for k, _, _ in KEY_STATS},
        "breakdown": ev.breakdown,
        "contributions": [{"item": i.name, "score_share": round(c, 3)} for i, c in contributions(scorer, build)],
        "snowball_items": snowball_items(build),
        "scenarios": scenario_table(db, scorer.god, scorer.ctx, build),
    }


def _print_build(rank: int, scorer: Scorer, build: Build, db: Database, detail: bool) -> None:
    ev, base = build.evaluation, scorer.baseline
    head = f"#{rank}  score {ev.score:.3f}   cost {build.cost}g"
    print(head)
    print("    Starter: " + (build.starter.name if build.starter else "-"))
    for n, it in enumerate(build.items, 1):
        why = buy_reason(it)
        print(f"    {n}. {it.name}  ({it.cost or '?'}g)" + (f"   <- {why.split(':')[0]}" if why else ""))
    print(f"    Burst {ev.burst:,.0f} ({ev.burst / base.burst:.2f}x)   "
          f"DPS {ev.dps:,.0f} ({ev.dps / base.dps:.2f}x)   "
          f"EHP {ev.ehp:,.0f} ({ev.ehp / base.ehp:.2f}x)")
    if not detail:
        return
    print("    Stats: " + ", ".join(f"{label} {fmt.format(ev.stats.get(k, 0))}" for k, label, fmt in KEY_STATS))
    b = ev.breakdown
    print(f"    Multipliers: crit x{b['crit_factor']}, ability x{b['ability_mult']}, basic x{b['basic_mult']}, "
          f"mitigation abil {b['mitigation_ability']} / basic {b['mitigation_basic']} "
          f"(target prot {b['target_protection_after_shred']}), rotation CD {b['effective_rotation_cd']}s")
    print(f"    Burst split: {b['burst_parts']}   DPS split: {b['dps_parts']}")
    if b.get("utility_notes"):
        print("    Utility: " + "; ".join(b["utility_notes"]))
    if ev.stats.get("wasted_attack_speed", 0) > 0:
        print(f"    Note: {ev.stats['wasted_attack_speed']:.2f} attack speed over cap is wasted")
    print("    Item value (score lost if removed):")
    for it, c in contributions(scorer, build):
        print(f"      {it.name:<24} {c:6.1%}")


def cmd_build(db: Database, args) -> int:
    god = db.god(args.god)
    if getattr(args, 'aspect', False) and god.name in db.aspect_models:
        god = db.with_aspect(god)
    ctx = _context(db, god, args)
    cons = Constraints(
        require=[db.item(n) for n in args.require],
        exclude={db.item(n).name for n in args.exclude},
        starter=db.item(args.starter) if args.starter else None,
        budget=args.budget,
        min_defense=args.min_defense,
    )
    builds, scorer = optimize(db, god, ctx, cons, beam_width=args.beam, top=args.top)
    relics = suggest_relics(db, god, ctx)
    if args.json:
        print(json.dumps({
            "god": god.name, "class": god.god_class, "archetype": god.archetype,
            "damage_type": god.damage_type, "context": vars(ctx),
            "builds": [_build_dict(scorer, b, db) for b in builds],
            "relics": [r["name"] for r in relics],
            "data_verified": god.verified and all(i.verified for b in builds for i in b.all_items),
            "unverified_items": sorted({i.name for b in builds for i in b.all_items if not i.verified}),
            "aspect": _aspect_note(db, god.name, god.aspect),
        }, indent=2))
        return 0
    print(f"{god.name} — {god.god_class} ({god.archetype}, {god.damage_type}) | role {ctx.role or god.roles[0]} | "
          f"mode {ctx.mode} | target {ctx.target}")
    print(f"Archetype: {god.kit['description']}")
    print("Key: Burst = one full rotation; DPS = damage/s over 6s; EHP = damage you can take; (Nx) = times stronger than "
          "no items. Score combines them for this mode (+ utility, pro ratings, gold cost); compare it only between "
          "builds for the same god and settings.")
    print(f"Aspect: {_aspect_note(db, god.name, god.aspect)}\n")
    for n, b in enumerate(builds, 1):
        _print_build(n, scorer, b, db, detail=(n == 1))
        farm = [i.name for i in b.items if is_farm_stacking(i)]
        if farm:
            print(f"    Stacking items first: {', '.join(farm)} (they evolve from farm/fights; bought late they never finish stacking)")
        sb = snowball_items(b)
        if sb:
            t = scenario_table(db, god, ctx, b)
            print(f"    Snowball items: {', '.join(sb)}")
            print("    Stacks  " + "   ".join(f"{lvl}: burst {v['burst']:,} / DPS {v['dps']:,} / EHP {v['ehp']:,}"
                                             for lvl, v in t.items()))
        print()
    print("Relics: " + "; ".join(f"{r['name']} — {r['description']}"
                                 + (f" (upgrades to {r['upgrade']})" if r.get("upgrade") else "") for r in relics))
    if not all(i.verified for b in builds for i in b.all_items):
        print("\n[!] Item/god numbers are unverified seed data — run `python -m smite2 scrape` to refresh.")
    return 0


def cmd_evaluate(db: Database, args) -> int:
    god = db.god(args.god)
    if getattr(args, 'aspect', False) and god.name in db.aspect_models:
        god = db.with_aspect(god)
    ctx = _context(db, god, args)
    items = [db.item(n.strip()) for n in args.items.split(",") if n.strip()]
    starters = [i for i in items if i.tier == "starter"]
    t3 = [i for i in items if i.tier == "t3"]
    scorer = Scorer(db, god, ctx)
    starter = starters[0] if starters else None
    order = buy_order(scorer, starter, t3)
    yours = Build(starter, order, scorer([*([starter] if starter else []), *order]))
    best, _ = optimize(db, god, ctx, Constraints(require=[], exclude=set()), beam_width=args.beam, top=1)
    if args.json:
        print(json.dumps({"yours": _build_dict(scorer, yours, db), "optimal": _build_dict(scorer, best[0], db),
                          "ratio_to_optimal": round(yours.evaluation.score / best[0].evaluation.score, 3)}, indent=2))
        return 0
    print(f"{god.name} | mode {ctx.mode} | target {ctx.target}\n")
    print("YOUR BUILD (reordered for power spikes)")
    _print_build(1, scorer, yours, db, detail=True)
    print(f"\n    -> {yours.evaluation.score / best[0].evaluation.score:.1%} of optimal\n")
    weakest = contributions(scorer, yours)[-1][0]
    alts = best_replacements(db, scorer, yours, weakest)
    print(f"Weakest slot: {weakest.name}. Best swaps: "
          + ", ".join(f"{c.name} ({s / yours.evaluation.score - 1:+.1%})" for c, s in alts))
    print("\nOPTIMAL")
    _print_build(1, scorer, best[0], db, detail=False)
    return 0


def cmd_gods(db: Database, args) -> int:
    rows = [g for g in db.gods.values()
            if (not args.role or args.role in g.roles) and (not args.cls or g.god_class == args.cls)]
    for g in sorted(rows, key=lambda g: g.name):
        print(f"{g.name:<15} {g.god_class:<9} {'/'.join(g.roles):<15} {g.damage_type:<9} {g.archetype}")
    return 0


def cmd_items(db: Database, args) -> int:
    rows = [i for i in db.items.values()
            if (not args.tier or i.tier == args.tier) and (not args.stat or args.stat in i.stats)
            and (not args.category or i.category == args.category)]
    for i in sorted(rows, key=lambda i: (i.tier, i.category, i.name)):
        stats = ", ".join(f"{k} {v}" for k, v in i.stats.items())
        flag = "  [disabled]" if i.disabled else ("" if i.verified else "  [unverified]")
        print(f"{i.name:<24} {i.category or i.tier:<10} {i.cost or '?':>5}g  {stats}{flag}")
    print(f"\n{len(rows)} items ({sum(i.verified for i in rows)} verified)")
    return 0


def cmd_show(db: Database, args) -> int:
    try:
        obj = db.god(args.name)
        out = {"name": obj.name, "class": obj.god_class, "roles": obj.roles, "damage_type": obj.damage_type,
               "attack_range": obj.attack_range, "archetype": obj.archetype, "base": obj.base, "kit": obj.kit,
               "verified": obj.verified}
    except KeyError:
        obj = db.item(args.name)
        out = {"name": obj.name, "tier": obj.tier, "cost": obj.cost, "stats": obj.stats, "effects": obj.effects,
               "tags": obj.tags, "roles": obj.roles, "upgrades_from": obj.upgrades_from, "category": obj.category,
               "passive_text": obj.passive_text, "verified": obj.verified, "audit": obj.audit, "source": obj.source,
               "disabled": obj.disabled}
    print(json.dumps(out, indent=2))
    return 0


def cmd_validate(db: Database, args) -> int:
    problems = db.validate()
    for p in problems:
        print("ERROR", p)
    print(f"{len(db.gods)} gods, {len(db.items)} items, {len(db.relics)} relics; {len(problems)} problems")
    return 1 if problems else 0


def _aspect_note(db: Database, name: str, scored: str | None = None) -> str:
    if scored:
        return f"{scored} - scored WITH the aspect (approximate model, data/aspect_models.json)."
    a = db.aspects.get(name)
    if not a:
        return "none yet" if name in db.no_aspect_yet else "unknown"
    state = "" if a.get("released") else " (not released yet)"
    hint = " Add --aspect to score it." if name in db.aspect_models else ""
    return f"{a['name']}{state}. Builds are for the base kit; run `aspect {name}` for what it changes.{hint}"


def cmd_aspect(db: Database, args) -> int:
    god = db.god(args.god)
    a = db.aspects.get(god.name)
    if args.json:
        print(json.dumps(a or {"name": None, "no_aspect_yet": god.name in db.no_aspect_yet}, indent=2, ensure_ascii=False))
        return 0
    if not a:
        print(f"{god.name}: {'no aspect yet (game-client data)' if god.name in db.no_aspect_yet else 'no aspect recorded'}")
        return 0
    print(f"{god.name} — {a['name']}{'' if a.get('released') else ' (not released yet)'}")
    print(f"  {a['summary']}")
    for ab in a.get("enhanced_abilities", []):
        print(f"\n  [{ab['slot']}] {ab['name']}: {ab['description']}")
        for line in ab["stats"]:
            print(f"    - {line}")
        for line in ab["notes"]:
            print(f"    * {line}")
    print(f"\n  Source: {a.get('source', '')}")
    return 0


def cmd_explain(db: Database, args) -> int:
    from .explain import explain, format_explain
    god = db.god(args.god)
    if getattr(args, "aspect", False) and god.name in db.aspect_models:
        god = db.with_aspect(god)
    r = explain(db, god, db.item(args.item), _context(db, god, args), beam=args.beam)
    print(json.dumps(r, indent=2) if args.json else format_explain(r))
    return 0


def cmd_scrape(db: Database, args) -> int:
    from . import scrape
    return scrape.main(args)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="smite2", description="SMITE 2 loadout optimizer")
    ap.add_argument("--data", default=None, help="data directory (default: repo data/)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("build", help="find optimal builds for a god")
    p.add_argument("god")
    _add_context_args(p)
    p.add_argument("--require", action="append", default=[], metavar="ITEM", help="item that must be in the build")
    p.add_argument("--exclude", action="append", default=[], metavar="ITEM", help="item to never use")
    p.add_argument("--starter", help="force a starter item")
    p.add_argument("--budget", type=int, help="max total gold")
    p.add_argument("--min-defense", type=int, default=0, metavar="N", help="at least N defensive items")
    p.add_argument("--top", type=int, default=3, help="number of builds to show")
    p.add_argument("--beam", type=int, default=120, help="search beam width (higher = slower, more thorough)")
    p.set_defaults(fn=cmd_build)

    p = sub.add_parser("evaluate", help="score your own build and compare with the optimum")
    p.add_argument("god")
    p.add_argument("items", help="comma-separated item names (starter optional)")
    _add_context_args(p)
    p.add_argument("--beam", type=int, default=80)
    p.set_defaults(fn=cmd_evaluate)

    p = sub.add_parser("gods", help="list gods")
    p.add_argument("--role", choices=sorted(ROLES))
    p.add_argument("--class", dest="cls", choices=["Guardian", "Warrior", "Assassin", "Mage", "Hunter"])
    p.set_defaults(fn=cmd_gods)

    p = sub.add_parser("items", help="list items")
    p.add_argument("--tier", choices=["starter", "t3"])
    p.add_argument("--stat", help="only items with this stat")
    p.add_argument("--category", choices=["offensive", "defensive", "hybrid", "starter"])
    p.set_defaults(fn=cmd_items)

    p = sub.add_parser("show", help="show one god or item as JSON")
    p.add_argument("name")
    p.set_defaults(fn=cmd_show)

    p = sub.add_parser("explain", help="pros and cons of one item for one god, across matchups")
    p.add_argument("item")
    p.add_argument("god")
    _add_context_args(p)
    p.add_argument("--beam", type=int, default=60)
    p.set_defaults(fn=cmd_explain)

    p = sub.add_parser("aspect", help="show what a god's Aspect changes")
    p.add_argument("god")
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_aspect)

    p = sub.add_parser("validate", help="check the data files")
    p.set_defaults(fn=cmd_validate)

    p = sub.add_parser("scrape", help="refresh data from wiki.smite2.com")
    p.add_argument("--what", choices=["items", "gods", "all"], default="all")
    p.add_argument("--merge", action="store_true", help="merge scraped numbers into data/*.json")
    p.add_argument("--api", default="https://wiki.smite2.com/api.php")
    p.set_defaults(fn=cmd_scrape)

    args = ap.parse_args(argv)
    db = Database(args.data) if args.data else Database()
    try:
        return args.fn(db, args)
    except (KeyError, ValueError) as e:
        print(f"error: {e.args[0] if e.args else e}", file=sys.stderr)
        return 2
