"""Load and validate the SMITE 2 god/item database in data/."""

from __future__ import annotations

import difflib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

STAT_KEYS = {
    "strength", "intelligence",
    "attack_speed", "crit_chance", "crit_damage", "basic_damage",
    "penetration", "flat_penetration", "ability_penetration", "basic_penetration",
    "physical_protection", "magical_protection", "max_health", "max_mana",
    "hp5", "mp5", "cooldown_rate", "cooldown_haste", "lifesteal", "movement_speed",
    "uncapped_basic_penetration", "uncapped_ability_penetration",
    # tracked but not used by the combat model yet
    "dampening", "plating", "tenacity", "echo", "pathfinding",
}

EFFECT_KINDS = {
    "stat", "stat_per_stack", "convert", "stat_mult", "adaptive_stat",
    "damage_mult", "proc", "target_prot_reduction", "damage_reduction",
    "shield", "utility",
}

TIERS = {"starter", "t3"}
ROLES = {"Solo", "Jungle", "Mid", "Support", "Carry"}
MODES = {"burst", "dps", "balanced", "tank", "lifesteal"}


def norm(name: str) -> str:
    """Normalize a name for matching: lowercase, alphanumerics only."""
    return re.sub(r"[^a-z0-9]", "", name.lower())


@dataclass(eq=False)  # identity-hashed: items are used in sets
class Item:
    name: str
    tier: str
    cost: int
    stats: dict
    effects: list = field(default_factory=list)
    tags: list = field(default_factory=list)
    roles: list = field(default_factory=list)
    upgrades_from: str | None = None
    verified: bool = False
    category: str = ""
    disabled: bool = False
    build_late: str = ""      # why this item belongs late in the buy order (multiplier/scaling items)
    buy_hint: str = ""        # "early" (buy in the first slots) or "not_first" (never the first item)
    active: bool = False
    passive_text: str = ""
    audit: str = ""
    source: str = ""

    UNKNOWN_COST = 2500  # stand-in for items whose cost wasn't found

    @property
    def price(self) -> int:
        """Cost for budgeting; unknown (0) costs count as an average tier-3 price."""
        return self.cost or self.UNKNOWN_COST

    @property
    def utility_tags(self) -> set:
        return {e["tag"] for e in self.effects if e["kind"] == "utility"}


@dataclass
class God:
    name: str
    pantheon: str
    god_class: str
    roles: list
    damage_type: str
    attack_range: str
    archetype: str
    base: dict
    kit: dict
    verified: bool = False
    builtin_utility: list = field(default_factory=list)  # e.g. Medusa's Acid Spray anti-heal
    kit_effects: list = field(default_factory=list)      # ability buffs modeled like item effects
    no_starter: bool = False                             # god has a built-in starter (Ratatoskr's acorn)
    aspect: str | None = None                            # set when scored with --aspect

    @property
    def default_mode(self) -> str:
        return self.kit["default_mode"]


class Database:
    def __init__(self, data_dir: Path | str = DATA_DIR):
        data_dir = Path(data_dir)
        self.mechanics = json.loads((data_dir / "mechanics.json").read_text())
        gods_raw = json.loads((data_dir / "gods.json").read_text())
        items_raw = json.loads((data_dir / "items.json").read_text())
        aspects_path = data_dir / "aspects.json"
        aspects_raw = json.loads(aspects_path.read_text()) if aspects_path.exists() else {"aspects": {}, "_meta": {}}
        self.aspects: dict[str, dict] = aspects_raw["aspects"]
        self.no_aspect_yet: list[str] = aspects_raw["_meta"].get("no_aspect_yet", [])
        comm_path = data_dir / "community_builds.json"
        self.community: dict = json.loads(comm_path.read_text()) if comm_path.exists() else {}
        tiers_path = data_dir / "meta_tiers.json"
        self.meta_tiers: dict[str, dict] = json.loads(tiers_path.read_text())["items"] if tiers_path.exists() else {}
        models_path = data_dir / "aspect_models.json"
        self.aspect_models: dict[str, dict] = (json.loads(models_path.read_text())["models"]
                                               if models_path.exists() else {})

        self.archetypes = gods_raw["archetypes"]
        self.class_base = gods_raw["class_base"]
        self.gods: dict[str, God] = {}
        for g in gods_raw["gods"]:
            kit = {**self.archetypes[g["archetype"]], **g.get("kit", {})}
            base = {**self.class_base[g["class"]], **g.get("base", {})}
            god = God(
                name=g["name"], pantheon=g.get("pantheon", ""), god_class=g["class"],
                roles=g["roles"], damage_type=g["damage_type"], attack_range=g["attack_range"],
                archetype=g["archetype"], base=base, kit=kit, verified=g.get("verified", False),
                builtin_utility=g.get("builtin_utility", []), kit_effects=g.get("kit_effects", []),
                no_starter=g.get("no_starter", False),
            )
            self.gods[norm(god.name)] = god

        self.items: dict[str, Item] = {}
        for i in items_raw["items"]:
            item = Item(
                name=i["name"], tier=i["tier"], cost=i["cost"], stats=i.get("stats", {}),
                effects=i.get("effects", []), tags=i.get("tags", []), roles=i.get("roles", []),
                upgrades_from=i.get("upgrades_from"), verified=i.get("verified", False),
                category=i.get("category", ""), disabled=i.get("disabled", False), active=i.get("active", False),
                build_late=i.get("build_late", ""), buy_hint=i.get("buy_hint", ""),
                passive_text=i.get("passive_text", ""), audit=i.get("audit", ""), source=i.get("source", ""),
            )
            self.items[norm(item.name)] = item
        self.relics = items_raw.get("relics", [])

    # -- lookup -------------------------------------------------------------

    def _find(self, table: dict, name: str, kind: str):
        key = norm(name)
        if key in table:
            return table[key]
        prefixed = [v for k, v in table.items() if k.startswith(key)]
        if len(prefixed) == 1:
            return prefixed[0]
        # also accept a starter's base (pre-upgrade) name
        if kind == "item":
            for v in table.values():
                if v.upgrades_from and norm(v.upgrades_from) == key:
                    return v
        names = [v.name for v in table.values()]
        close = difflib.get_close_matches(name, names, n=3, cutoff=0.5)
        hint = f" Did you mean: {', '.join(close)}?" if close else ""
        raise KeyError(f"Unknown {kind} '{name}'.{hint}")

    def god(self, name: str) -> God:
        return self._find(self.gods, name, "god")

    def with_aspect(self, god: God) -> God:
        """A copy of the god scored with its Aspect (data/aspect_models.json)."""
        import copy
        m = self.aspect_models.get(god.name)
        if not m:
            raise KeyError(f"No aspect model for {god.name} yet; `aspect {god.name}` shows what it changes.")
        g = copy.deepcopy(god)
        g.kit = {**g.kit, **m.get("kit", {})}
        if "kit_effects" in m:
            g.kit_effects = m["kit_effects"]
        for key in ("attack_range", "roles", "damage_type"):
            if key in m:
                setattr(g, key, m[key])
        g.name = god.name  # keep lookups working; output labels the aspect separately
        g.aspect = m.get("aspect", "aspect")
        return g

    def item(self, name: str) -> Item:
        return self._find(self.items, name, "item")

    def starters(self) -> list[Item]:
        return [i for i in self.items.values() if i.tier == "starter" and not i.disabled]

    def tier3(self) -> list[Item]:
        return [i for i in self.items.values() if i.tier == "t3" and not i.disabled]

    # -- validation ---------------------------------------------------------

    def validate(self) -> list[str]:
        problems = []
        for item in self.items.values():
            where = f"item '{item.name}'"
            if item.tier not in TIERS:
                problems.append(f"{where}: unknown tier '{item.tier}'")
            for k in item.stats:
                if k not in STAT_KEYS:
                    problems.append(f"{where}: unknown stat '{k}'")
            for r in item.roles:
                if r not in ROLES:
                    problems.append(f"{where}: unknown role '{r}'")
            for e in item.effects:
                kind = e.get("kind")
                if kind not in EFFECT_KINDS:
                    problems.append(f"{where}: unknown effect kind '{kind}'")
                    continue
                for key in ("stat", "from", "to"):
                    if key in e and e[key] not in STAT_KEYS:
                        problems.append(f"{where}: effect {kind} references unknown stat '{e[key]}'")
                if kind == "proc" and e.get("applies_on") not in {"ability", "basic", "time", "echo"}:
                    problems.append(f"{where}: proc needs applies_on ability|basic|time|echo")
                if kind == "damage_mult" and e.get("applies") not in {"ability", "basic", "all"}:
                    problems.append(f"{where}: damage_mult needs applies ability|basic|all")
                if kind == "adaptive_stat" and not ({"value", "strength", "intelligence"} & set(e)):
                    problems.append(f"{where}: adaptive_stat needs strength/intelligence values")
                if kind == "proc" and not (isinstance(e.get("per_combo", 1), (int, float))
                                           or e.get("per_combo") == "abilities"):
                    problems.append(f"{where}: per_combo must be a number or 'abilities'")
                if not 0 <= e.get("uptime", 1) <= 1:
                    problems.append(f"{where}: uptime must be within [0, 1]")
        for god in self.gods.values():
            where = f"god '{god.name}'"
            if god.damage_type not in {"physical", "magical"}:
                problems.append(f"{where}: damage_type must be physical|magical")
            if god.kit.get("default_mode") not in MODES:
                problems.append(f"{where}: archetype default_mode invalid")
            for r in god.roles:
                if r not in ROLES:
                    problems.append(f"{where}: unknown role '{r}'")
        return problems
