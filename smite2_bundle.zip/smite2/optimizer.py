"""Build search: beam search over item sets, then swap-based hill climbing."""

from __future__ import annotations

from dataclasses import dataclass

from .data import Database, God, Item
from .model import Context, Evaluation, Scorer


@dataclass
class Build:
    starter: Item | None
    items: list[Item]          # tier-3 items in recommended buy order
    evaluation: Evaluation

    @property
    def all_items(self) -> list[Item]:
        return ([self.starter] if self.starter else []) + self.items

    @property
    def cost(self) -> int:
        return sum(i.price for i in self.all_items)


@dataclass
class Constraints:
    require: list[Item]
    exclude: set[str]
    starter: Item | None = None
    budget: int | None = None
    min_defense: int = 0


def is_defensive(item: Item) -> bool:
    prot = item.stats.get("physical_protection", 0) + item.stats.get("magical_protection", 0)
    return "defense" in item.tags or prot >= 50


def off_scaling(god: God, item: Item, ctx_mode: str = "") -> bool:
    """Strength item on an Intelligence-scaling ability god (or the reverse).

    The model credits Strength procs (Heartseeker, The Crusher...) to every ability, but in-game they
    underperform on gods whose abilities barely scale with Strength (player reports: Khepri, Sylvanus,
    2026-11). Basic-attack carries are exempt: magical carries like Nut do build Strength on-hit items.
    Adaptive items are never off-scaling (they give whichever stat you build)."""
    if god.kit.get("default_mode") == "dps" or ctx_mode in ("crit", "critls"):
        return False
    s, i = god.kit.get("combo_strength", 0), god.kit.get("combo_intelligence", 0)
    if item.stats.get("strength") and not item.stats.get("intelligence"):
        return s < 0.25 * i
    if item.stats.get("intelligence") and not item.stats.get("strength"):
        return i < 0.25 * s
    return False


def wrong_stat(item: Item, scaling: str) -> bool:
    """With a forced scaling, drop items that only give the other stat (adaptive items adapt, so they stay)."""
    if scaling == "auto":
        return False
    want, other = ("strength", "intelligence") if scaling == "strength" else ("intelligence", "strength")
    adaptive = any(e["kind"] == "adaptive_stat" for e in item.effects)
    if item.stats.get(other) and not item.stats.get(want) and not adaptive:
        return True
    # damage items that give neither stat (attack speed / on-hit) don't belong in a forced-stat build
    offensive = item.category == "offensive" or item.tier == "starter" and not is_defensive(item)
    return offensive and not item.stats.get(want) and not adaptive


def _inv(starter: Item | None, items) -> list[Item]:
    """Inventory list; starter is None for gods that don't buy one (e.g. Ratatoskr's acorn)."""
    return ([starter] if starter else []) + list(items)


def _starter_pool(db: Database, god: God, ctx: Context, cons: Constraints) -> list[Item | None]:
    if god.no_starter:
        return [None]
    if cons.starter:
        return [cons.starter]
    role = ctx.role or god.roles[0]
    pool = [s for s in db.starters() if role in s.roles and s.name not in cons.exclude and not wrong_stat(s, ctx.scaling)]
    return pool or [s for s in db.starters() if s.name not in cons.exclude]


def optimize(db: Database, god: God, ctx: Context, cons: Constraints,
             beam_width: int = 120, top: int = 3) -> tuple[list[Build], Scorer]:
    scorer = Scorer(db, god, ctx)
    slots = db.mechanics["inventory"]["item_slots"]
    required = [i for i in cons.require if i.tier == "t3"]
    if len(required) > slots:
        raise ValueError(f"Too many required items ({len(required)} > {slots} slots)")
    candidates = [i for i in db.tier3() if i.name not in cons.exclude and i not in required
                  and not (off_scaling(god, i, ctx.mode) and not ctx.aspect and ctx.scaling == "auto")
                  and not wrong_stat(i, ctx.scaling)]  # aspects/off-stat builds can flip scaling (Agni -> STR)
    starters = _starter_pool(db, god, ctx, cons)
    max_actives = db.mechanics["inventory"].get("max_active_items", 99)
    cheapest_defense = min((i.price for i in candidates if is_defensive(i)), default=10**9)

    def within_budget(items, final: bool = True) -> bool:
        """Budget check, plus whether the min-defense requirement can still be met."""
        if cons.budget is not None and sum(i.price for i in items) > cons.budget:
            return False
        t3 = [i for i in items if i.tier == "t3"]
        if sum(i.active for i in items) > max_actives:
            return False
        open_slots = 0 if final else slots - len(t3)
        if open_slots and cons.budget is not None:
            # slots we can still afford to fill with the cheapest defensive item
            left = cons.budget - sum(i.price for i in items)
            open_slots = min(open_slots, left // cheapest_defense)
        return sum(map(is_defensive, t3)) + open_slots >= cons.min_defense

    def score(starter, items) -> float:
        return scorer(_inv(starter, items)).score

    # Beam search: states are (starter, frozenset of T3 items).
    beam = {(s, frozenset(required)) for s in starters}
    for _ in range(slots - len(required)):
        expanded = {}
        for starter, chosen in beam:
            for cand in candidates:
                if cand in chosen:
                    continue
                nxt = chosen | {cand}
                key = (starter, nxt)
                if key in expanded or not within_budget(_inv(starter, nxt), final=False):
                    continue
                expanded[key] = score(starter, nxt)
        if not expanded:
            break
        ranked = sorted(expanded.items(), key=lambda kv: kv[1], reverse=True)
        beam = {k for k, _ in ranked[:beam_width]}

    # The beam can stop short when the budget runs out; drop builds that miss the constraints.
    feasible = [k for k in beam if within_budget(_inv(k[0], k[1]))]
    if not feasible:
        raise ValueError("No build satisfies the constraints (budget / min-defense / required items).")
    finals = sorted(feasible, key=lambda k: score(*k), reverse=True)[: max(top * 3, 10)]
    polished = {}
    for starter, chosen in finals:
        starter, chosen = _hill_climb(starter, set(chosen), set(required), candidates, starters,
                                      score, within_budget)
        polished[(starter, frozenset(chosen))] = score(starter, chosen)

    if ctx.enemy_cc_heavy:
        polished = {k: v for k, v in (_with_anti_cc(k, score, candidates, required, cons, within_budget) for k in polished)}
    builds = []
    for (starter, chosen), _ in sorted(polished.items(), key=lambda kv: kv[1], reverse=True)[:top]:
        first_budget = db.mechanics.get("game_modes", {}).get(ctx.game_mode, {}).get("starting_gold")
        order = buy_order(scorer, None if first_budget else starter, list(chosen), first_budget)
        builds.append(Build(starter, order, scorer(_inv(starter, order))))
    return builds, scorer


def _with_anti_cc(key, score, candidates, required, cons, within_budget):
    """Counter CC is an explicit ask: make sure the build holds at least one item that beats crowd control,
    swapping in whichever one costs the build the least."""
    from .model import ANTI_CC
    anti = set().union(*(names for names, _ in ANTI_CC.values()))
    starter, chosen = key
    if any(i.name in anti for i in chosen):
        return (starter, frozenset(chosen)), score(starter, chosen)
    best = None
    for out in [i for i in chosen if i not in required]:
        for cand in candidates:
            if cand.name in anti and cand not in chosen:
                trial = (set(chosen) - {out}) | {cand}
                if within_budget(_inv(starter, trial)):
                    sc = score(starter, trial)
                    if best is None or sc > best[1]:
                        best = ((starter, frozenset(trial)), sc)
    return best or ((starter, frozenset(chosen)), score(starter, chosen))


def _hill_climb(starter, chosen, required, candidates, starters, score, within_budget):
    improved = True
    while improved:
        improved = False
        best = score(starter, chosen)
        for out in list(chosen - required):
            for cand in candidates:
                if cand in chosen:
                    continue
                trial = (chosen - {out}) | {cand}
                if within_budget(_inv(starter, trial)) and score(starter, trial) > best + 1e-9:
                    chosen, best, improved = trial, score(starter, trial), True
                    break
        for s in starters:
            if s is not starter and within_budget(_inv(s, chosen)) and score(s, chosen) > best + 1e-9:
                starter, best, improved = s, score(s, chosen), True
    return starter, chosen


def buy_order(scorer: Scorer, starter: Item | None, items: list[Item],
              first_budget: int | None = None) -> list[Item]:
    """Order a finished build the way it should be bought.

    1. Farm-stacking items (Transcendence, Book of Thoth...) first: they evolve over many minutes of farm.
    2. Kill-stacking items next (Rage, Necronomicon, Doom Orb...): their stacks accrue from fights.
    3. The rest by power spike per gold, leaning toward cheaper items (cheap items complete sooner).
    4. Multiplier items last (Rod of Tahuti, Obsidian Shard, Deathbringer, Avatar's Parashu...): they multiply
       stats you must already own, so each is worth the most once the build around it exists.
    first_budget: the first purchase must fit it (Assault's starting gold).
    """
    farm = sorted((i for i in items if is_farm_stacking(i)), key=lambda i: i.price)
    kills = sorted((i for i in items if i not in farm and is_kill_stacking(i) and not i.build_late), key=lambda i: i.price)
    late = [i for i in items if i.build_late and i not in farm]
    early = [i for i in items if i.buy_hint == "early" and i not in farm and i not in kills and i not in late]
    rest = [i for i in items if i not in farm and i not in kills and i not in late and i not in early]
    owned = [starter] if starter else []
    order: list[Item] = []

    def take(pool: list[Item], cost_weight: float) -> None:
        while pool:
            base = scorer(owned).score
            choices = pool
            if first_budget is not None and not order:
                choices = [i for i in pool if i.price <= first_budget] or pool
            best = max(choices, key=lambda i: (scorer([*owned, i]).score - base) / i.price ** cost_weight)
            order.append(best); owned.append(best); pool.remove(best)

    if first_budget is not None:
        # the first buy must be affordable: if nothing from the early groups fits, open with the best cheap item
        early = farm + kills
        if early and all(i.price > first_budget for i in early):
            fits = [i for i in rest if i.price <= first_budget]
            if fits:
                take([max(fits, key=lambda i: scorer([*owned, i]).score)], 1.0)
                rest = [i for i in rest if i not in order]
    order += farm; owned += farm
    order += kills; owned += kills
    take(early, 1.0)    # pro advice: these are first/second/third items
    take(rest, 1.5)     # power per gold, tilted toward cheaper items
    take(late, 1.0)     # multipliers: biggest gain first once everything else is owned
    # where top players' slot data exists for this god and role, follow their real order (rule order fills gaps)
    slots = community_slots(scorer.db, scorer.god, scorer.ctx)
    if slots:
        rank = {it.name: k + 1 for k, it in enumerate(order)}
        order.sort(key=lambda it: slots.get(it.name, rank[it.name]))
        if first_budget is not None and order and order[0].price > first_budget:
            k = next((k for k, it in enumerate(order) if it.price <= first_budget), 0)
            order.insert(0, order.pop(k))
    # pro advice: some items should never be the first buy (Book of Thoth goes 2nd)
    if len(order) > 1 and order[0].buy_hint == "not_first":
        swap = 1
        if first_budget is not None:
            swap = next((k for k in range(1, len(order)) if order[k].price <= first_budget), 0)
        if swap:
            order[0], order[swap] = order[swap], order[0]
    return order


def community_slots(db, god, ctx) -> dict:
    """Average slot top players buy each item in, for this god and role (god-level data only)."""
    cb = getattr(db, "community", None) or {}
    g = cb.get("gods", {}).get(f"{god.name}|{ctx.role or god.roles[0]}")
    if not g or g["matches"] < db.mechanics.get("community_prior", {}).get("min_matches", 100):
        return {}
    return {n: v["avg_slot"] for n, v in g["items"].items() if v["share"] >= 5}


def buy_reason(item: Item) -> str:
    if is_farm_stacking(item):
        return "stacking: buy early so it finishes stacking"
    if item.build_late:
        return "late: " + item.build_late
    if item.buy_hint == "early":
        return "early: top players buy it in the first two or three slots"
    if is_kill_stacking(item):
        return "kill stacks: buy early, it grows with every kill/assist"
    if item.buy_hint == "not_first":
        return "not first: top players buy it second, after a power item"
    return ""


def is_kill_stacking(item: Item) -> bool:
    return any(e.get("snowball") == "kills" for e in item.effects)


def is_farm_stacking(item: Item) -> bool:
    return any(e.get("snowball") == "farm" for e in item.effects)


def contributions(scorer: Scorer, build: Build) -> list[tuple[Item, float]]:
    """How much the score drops (fraction) if each item is removed."""
    full = scorer(build.all_items).score
    out = []
    for it in build.all_items:
        rest = [x for x in build.all_items if x is not it]
        out.append((it, 1 - scorer(rest).score / full))
    return sorted(out, key=lambda t: t[1], reverse=True)


def best_replacements(db: Database, scorer: Scorer, build: Build, item: Item, n: int = 3):
    """Best alternatives if `item` can't be bought (e.g. for a sell/swap decision)."""
    rest = [x for x in build.all_items if x is not item]
    owned = {x.name for x in build.all_items}
    pool = db.starters() if item.tier == "starter" else db.tier3()
    alts = [(c, scorer([*rest, c]).score) for c in pool if c.name not in owned]
    return sorted(alts, key=lambda t: t[1], reverse=True)[:n]


def suggest_relics(db: Database, god: God, ctx: Context) -> list[dict]:
    role = ctx.role or god.roles[0]
    flags = set()
    if ctx.enemy_cc_heavy:
        flags.add("enemy_cc_heavy")
    if ctx.mode in ("burst", "dps") and god.attack_range == "ranged":
        flags.add("enemy_burst_heavy")
    if role in ("Support", "Solo") or ctx.mode == "tank":
        flags.add("need_engage")
    if ctx.enemy_healing:
        flags.add("antiheal")
    if role == "Jungle":
        flags.add("jungle_clear")
    if role == "Support":
        flags.add("team_protection")
    # only starting relics are picked (free); their upgrades are listed alongside
    starting = [r for r in db.relics if not r.get("upgrades_from")]
    ranked = sorted(starting, key=lambda r: (ctx.enemy_cc_heavy and "enemy_cc_heavy" in r["use_when"],
                                             len(flags & set(r["use_when"]))), reverse=True)
    upgrades = {r["upgrades_from"]: r["name"] for r in db.relics if r.get("upgrades_from")}
    return [{**r, "upgrade": upgrades.get(r["name"])} for r in ranked[:2]]
