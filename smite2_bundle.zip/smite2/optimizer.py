"""Build search: beam search over item sets, then swap-based hill climbing."""

from __future__ import annotations

from dataclasses import dataclass

from .data import Database, God, Item
from .model import Context, Evaluation, Scorer


@dataclass
class Build:
    starter: Item | None
    items: list[Item]          # tier-3 items in recommended buy order
    evaluation: Evaluation

    @property
    def all_items(self) -> list[Item]:
        return ([self.starter] if self.starter else []) + self.items

    @property
    def cost(self) -> int:
        return sum(i.price for i in self.all_items)


@dataclass
class Constraints:
    require: list[Item]
    exclude: set[str]
    starter: Item | None = None
    budget: int | None = None
    min_defense: int = 0


def is_defensive(item: Item) -> bool:
    prot = item.stats.get("physical_protection", 0) + item.stats.get("magical_protection", 0)
    return "defense" in item.tags or prot >= 50


def off_scaling(god: God, item: Item) -> bool:
    """Strength item on an Intelligence-scaling ability god (or the reverse).

    The model credits Strength procs (Heartseeker, The Crusher...) to every ability, but in-game they
    underperform on gods whose abilities barely scale with Strength (player reports: Khepri, Sylvanus,
    2026-11). Basic-attack carries are exempt: magical carries like Nut do build Strength on-hit items.
    Adaptive items are never off-scaling (they give whichever stat you build)."""
    if god.kit.get("default_mode") == "dps":
        return False
    s, i = god.kit.get("combo_strength", 0), god.kit.get("combo_intelligence", 0)
    if item.stats.get("strength") and not item.stats.get("intelligence"):
        return s < 0.25 * i
    if item.stats.get("intelligence") and not item.stats.get("strength"):
        return i < 0.25 * s
    return False


def _inv(starter: Item | None, items) -> list[Item]:
    """Inventory list; starter is None for gods that don't buy one (e.g. Ratatoskr's acorn)."""
    return ([starter] if starter else []) + list(items)


def _starter_pool(db: Database, god: God, ctx: Context, cons: Constraints) -> list[Item | None]:
    if god.no_starter:
        return [None]
    if cons.starter:
        return [cons.starter]
    role = ctx.role or god.roles[0]
    pool = [s for s in db.starters() if role in s.roles and s.name not in cons.exclude]
    return pool or [s for s in db.starters() if s.name not in cons.exclude]


def optimize(db: Database, god: God, ctx: Context, cons: Constraints,
             beam_width: int = 120, top: int = 3) -> tuple[list[Build], Scorer]:
    scorer = Scorer(db, god, ctx)
    slots = db.mechanics["inventory"]["item_slots"]
    required = [i for i in cons.require if i.tier == "t3"]
    if len(required) > slots:
        raise ValueError(f"Too many required items ({len(required)} > {slots} slots)")
    candidates = [i for i in db.tier3() if i.name not in cons.exclude and i not in required
                  and not off_scaling(god, i)]
    starters = _starter_pool(db, god, ctx, cons)
    max_actives = db.mechanics["inventory"].get("max_active_items", 99)
    cheapest_defense = min((i.price for i in candidates if is_defensive(i)), default=10**9)

    def within_budget(items, final: bool = True) -> bool:
        """Budget check, plus whether the min-defense requirement can still be met."""
        if cons.budget is not None and sum(i.price for i in items) > cons.budget:
            return False
        t3 = [i for i in items if i.tier == "t3"]
        if sum(i.active for i in items) > max_actives:
            return False
        open_slots = 0 if final else slots - len(t3)
        if open_slots and cons.budget is not None:
            # slots we can still afford to fill with the cheapest defensive item
            left = cons.budget - sum(i.price for i in items)
            open_slots = min(open_slots, left // cheapest_defense)
        return sum(map(is_defensive, t3)) + open_slots >= cons.min_defense

    def score(starter, items) -> float:
        return scorer(_inv(starter, items)).score

    # Beam search: states are (starter, frozenset of T3 items).
    beam = {(s, frozenset(required)) for s in starters}
    for _ in range(slots - len(required)):
        expanded = {}
        for starter, chosen in beam:
            for cand in candidates:
                if cand in chosen:
                    continue
                nxt = chosen | {cand}
                key = (starter, nxt)
                if key in expanded or not within_budget(_inv(starter, nxt), final=False):
                    continue
                expanded[key] = score(starter, nxt)
        if not expanded:
            break
        ranked = sorted(expanded.items(), key=lambda kv: kv[1], reverse=True)
        beam = {k for k, _ in ranked[:beam_width]}

    # The beam can stop short when the budget runs out; drop builds that miss the constraints.
    feasible = [k for k in beam if within_budget(_inv(k[0], k[1]))]
    if not feasible:
        raise ValueError("No build satisfies the constraints (budget / min-defense / required items).")
    finals = sorted(feasible, key=lambda k: score(*k), reverse=True)[: max(top * 3, 10)]
    polished = {}
    for starter, chosen in finals:
        starter, chosen = _hill_climb(starter, set(chosen), set(required), candidates, starters,
                                      score, within_budget)
        polished[(starter, frozenset(chosen))] = score(starter, chosen)

    builds = []
    for (starter, chosen), _ in sorted(polished.items(), key=lambda kv: kv[1], reverse=True)[:top]:
        first_budget = db.mechanics.get("game_modes", {}).get(ctx.game_mode, {}).get("starting_gold")
        order = buy_order(scorer, None if first_budget else starter, list(chosen), first_budget)
        builds.append(Build(starter, order, scorer(_inv(starter, order))))
    return builds, scorer


def _hill_climb(starter, chosen, required, candidates, starters, score, within_budget):
    improved = True
    while improved:
        improved = False
        best = score(starter, chosen)
        for out in list(chosen - required):
            for cand in candidates:
                if cand in chosen:
                    continue
                trial = (chosen - {out}) | {cand}
                if within_budget(_inv(starter, trial)) and score(starter, trial) > best + 1e-9:
                    chosen, best, improved = trial, score(starter, trial), True
                    break
        for s in starters:
            if s is not starter and within_budget(_inv(s, chosen)) and score(s, chosen) > best + 1e-9:
                starter, best, improved = s, score(s, chosen), True
    return starter, chosen


def buy_order(scorer: Scorer, starter: Item | None, items: list[Item],
              first_budget: int | None = None) -> list[Item]:
    """Greedy power-spike order: next item = biggest score gain per gold from current inventory.
    first_budget limits the first pick (e.g. Assault's starting gold)."""
    owned = [starter] if starter else []
    remaining, order = list(items), []
    while remaining:
        base = scorer(owned).score
        pool = remaining
        if first_budget is not None and not order:
            pool = [it for it in remaining if it.price <= first_budget] or remaining
        best = max(pool, key=lambda it: (scorer([*owned, it]).score - base) / it.price)
        order.append(best)
        owned.append(best)
        remaining.remove(best)
    # Farm-stacking items (Transcendence, Book of Thoth, Devourer's Gauntlet, Gauntlet of Thebes) only reach
    # the stacks they are scored with if bought early: they evolve from minion/jungle damage over many minutes.
    # Move them to the front (keeping the first pick if it had to fit the starting gold).
    stacking = [it for it in order if is_farm_stacking(it)]
    if stacking:
        keep_first = 1 if first_budget is not None and order[0] not in stacking and order[0].price <= first_budget \
            and all(it.price > first_budget for it in stacking) else 0
        rest = [it for it in order[keep_first:] if it not in stacking]
        order = order[:keep_first] + stacking + rest
    return order


def is_farm_stacking(item: Item) -> bool:
    return any(e.get("snowball") == "farm" for e in item.effects)


def contributions(scorer: Scorer, build: Build) -> list[tuple[Item, float]]:
    """How much the score drops (fraction) if each item is removed."""
    full = scorer(build.all_items).score
    out = []
    for it in build.all_items:
        rest = [x for x in build.all_items if x is not it]
        out.append((it, 1 - scorer(rest).score / full))
    return sorted(out, key=lambda t: t[1], reverse=True)


def best_replacements(db: Database, scorer: Scorer, build: Build, item: Item, n: int = 3):
    """Best alternatives if `item` can't be bought (e.g. for a sell/swap decision)."""
    rest = [x for x in build.all_items if x is not item]
    owned = {x.name for x in build.all_items}
    pool = db.starters() if item.tier == "starter" else db.tier3()
    alts = [(c, scorer([*rest, c]).score) for c in pool if c.name not in owned]
    return sorted(alts, key=lambda t: t[1], reverse=True)[:n]


def suggest_relics(db: Database, god: God, ctx: Context) -> list[dict]:
    role = ctx.role or god.roles[0]
    flags = set()
    if ctx.enemy_cc_heavy:
        flags.add("enemy_cc_heavy")
    if ctx.mode in ("burst", "dps") and god.attack_range == "ranged":
        flags.add("enemy_burst_heavy")
    if role in ("Support", "Solo") or ctx.mode == "tank":
        flags.add("need_engage")
    if ctx.enemy_healing:
        flags.add("antiheal")
    if role == "Jungle":
        flags.add("jungle_clear")
    if role == "Support":
        flags.add("team_protection")
    # only starting relics are picked (free); their upgrades are listed alongside
    starting = [r for r in db.relics if not r.get("upgrades_from")]
    ranked = sorted(starting, key=lambda r: len(flags & set(r["use_when"])), reverse=True)
    upgrades = {r["upgrades_from"]: r["name"] for r in db.relics if r.get("upgrades_from")}
    return [{**r, "upgrade": upgrades.get(r["name"])} for r in ranked[:2]]
