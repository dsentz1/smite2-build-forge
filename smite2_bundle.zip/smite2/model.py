"""Combat model: turn a god + set of items into stats, burst, DPS, EHP and a score.

All formulas live here; all constants live in data/mechanics.json.
See docs/MODEL.md for the derivation and assumptions.
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field

from .data import Database, God, Item

MODE_WEIGHTS = {
    "burst":    {"burst": 0.70, "dps": 0.15, "ehp": 0.15},
    "dps":      {"burst": 0.15, "dps": 0.70, "ehp": 0.15},
    "balanced": {"burst": 0.25, "dps": 0.25, "ehp": 0.50},  # default; see BALANCED_BY_CLASS
    "tank":     {"burst": 0.05, "dps": 0.10, "ehp": 0.85},
}

# "Balanced" means different things per class: an all-round mage still carries damage and
# buys ~1 defensive item, while an all-round warrior is half tank.
BALANCED_BY_CLASS = {
    "Mage":     {"burst": 0.40, "dps": 0.30, "ehp": 0.30},
    "Hunter":   {"burst": 0.30, "dps": 0.40, "ehp": 0.30},
    "Assassin": {"burst": 0.40, "dps": 0.25, "ehp": 0.35},
    "Warrior":  {"burst": 0.20, "dps": 0.20, "ehp": 0.60},  # community solo builds run 4+ defensive items
    "Guardian": {"burst": 0.20, "dps": 0.20, "ehp": 0.60},
}


# Value of cooldown rate beyond rotation DPS: more frequent CC, engages, peel and burst windows.
# Calibrated against community builds (OB46): mids/supports/junglers prioritise cooldown items.
UPTIME_WEIGHT = {"burst": 0.30, "dps": 0.05, "balanced": 0.30, "tank": 0.45}


def mode_weights(god: God, mode: str) -> dict:
    if mode == "balanced":
        return BALANCED_BY_CLASS.get(god.god_class, MODE_WEIGHTS["balanced"])
    return MODE_WEIGHTS[mode]


@dataclass
class Context:
    mode: str = "balanced"
    target: str = "squishy"
    role: str | None = None
    enemy_physical_share: float = 0.5
    enemy_healing: bool = False
    enemy_cc_heavy: bool = False
    antiheal_penalty: float = 0.15  # score loss for no anti-heal vs a healing comp
    game_mode: str = "conquest"
    stacks: str = "even"  # snowball scenario: behind | even | ahead
    sustain_window: float | None = None  # seconds of healing counted into EHP (None = mechanics default)
    aura_bonus: float = 0.0  # game-mode value of aura items for every role (Joust: cramped 3v3 fights)


@dataclass
class Evaluation:
    stats: dict
    burst: float
    dps: float
    ehp: float
    score: float = 0.0
    breakdown: dict = field(default_factory=dict)
    utility: set = field(default_factory=set)


# Fraction of max stacks for snowball effects in each scenario ("even" keeps the data's values).
SNOWBALL_LEVELS = {"behind": 0.25, "even": None, "ahead": 1.0}


def scale_snowball(effect: dict, level: str) -> dict:
    """Rescale a snowballing effect (kill/farm/combat stacks) to the scenario's stack level."""
    frac = SNOWBALL_LEVELS[level]
    if frac is None or not effect.get("snowball"):
        return effect
    e = dict(effect)
    if e["kind"] == "stat_per_stack":
        e["assumed_stacks"] = e["max_stacks"] * frac
    else:
        e["uptime"] = frac
    return e


def _uptime(effect: dict) -> float:
    return effect.get("uptime", 1.0)


def aggregate_stats(db: Database, god: God, items: list[Item], stacks: str = "even") -> tuple[dict, list[dict]]:
    """Sum base + item stats and apply stat-type passives in a fixed order:
    flat stats / stacks -> conversions -> adaptive -> multipliers -> caps."""
    caps = db.mechanics["caps"]
    s = defaultdict(float)
    s["max_health"] = god.base["health"]
    s["max_mana"] = god.base["mana"]
    s["physical_protection"] = god.base["physical_protection"]
    s["magical_protection"] = god.base["magical_protection"]
    s["hp5"] = god.base["hp5"]
    s["mp5"] = god.base["mp5"]
    s["attack_speed"] = god.base.get("attack_speed_level_bonus", 0.0)  # +% AS from levels, additive with items

    effects = [scale_snowball(e, stacks) for e in list(god.kit_effects) + [e for it in items for e in it.effects]]
    for it in items:
        for k, v in it.stats.items():
            s[k] += v
    s["item_protections"] = sum(it.stats.get("physical_protection", 0) + it.stats.get("magical_protection", 0)
                                for it in items)
    for e in effects:
        if e["kind"] == "stat":
            s[e["stat"]] += e["value"] * _uptime(e)
        elif e["kind"] == "stat_per_stack":
            s[e["stat"]] += e["value"] * e.get("assumed_stacks", e["max_stacks"]) * _uptime(e)
    # Stats that don't come from items (god base + ability passives like Scylla's Quick Learner);
    # "item stat" passives (Rod of Tahuti, adaptive stats) must exclude these.
    base_vals = defaultdict(float, {"max_health": god.base["health"], "max_mana": god.base["mana"],
                                    "physical_protection": god.base["physical_protection"],
                                    "magical_protection": god.base["magical_protection"]})
    for e in god.kit_effects:
        if e["kind"] == "stat":
            base_vals[e["stat"]] += e["value"] * _uptime(e)
    def apply_converts(primary: bool) -> None:
        # conversions *from* STR/INT run after adaptive stats so they see the adaptive bonus
        for e in effects:
            if e["kind"] == "convert" and (e["from"] in ("strength", "intelligence")) == primary:
                source = s[e["from"]] - (base_vals.get(e["from"], 0) if e.get("from_items") else 0)
                s[e["to"]] += min(source * e["ratio"], e.get("cap", math.inf)) * _uptime(e)

    apply_converts(primary=False)
    for e in effects:
        if e["kind"] == "adaptive_stat":
            # Applies to the highest item stat; on a tie, the stat the god's kit scales with.
            item_str = s["strength"] - base_vals["strength"]
            item_int = s["intelligence"] - base_vals["intelligence"]
            if item_str != item_int:
                key = "strength" if item_str > item_int else "intelligence"
            else:
                # wiki (Stats): with no Strength/Intelligence items it defaults to the god's scaling stat,
                # hybrid gods default to Strength
                ks, ki = god.kit["combo_strength"], god.kit["combo_intelligence"]
                key = "strength" if ks > 0 or ki == 0 else "intelligence"
            s[key] += e.get(key, e.get("value", 0)) * _uptime(e)
    apply_converts(primary=True)
    for e in effects:
        if e["kind"] == "stat_mult":
            s[e["stat"]] *= 1 + e["value"] * _uptime(e)

    raw_as = god.base["attack_speed"] * (1 + s["attack_speed"])
    s["attack_speed_total"] = min(raw_as, caps["attack_speed"])
    # Cooldown Rate is not a % reduction: cooldown = base / (1 + CR/100), i.e. 50 CR -> 33% shorter
    # (SMITE 2 Alpha Weekend 1 notes). No cap is documented; a cap in mechanics.json is optional.
    s["cooldown_rate"] = min(s["cooldown_rate"], caps.get("cooldown_rate", math.inf))
    s["cooldown_reduction"] = s["cooldown_rate"] / (1 + s["cooldown_rate"])
    s["echo"] = min(s.get("echo", 0.0), 100.0)
    s["plating"] = min(s.get("plating", 0.0), caps.get("plating", 35))
    s["dampening"] = min(s.get("dampening", 0.0), caps.get("dampening", 35))
    s["crit_chance"] = min(s["crit_chance"], caps["crit_chance"])
    s["lifesteal"] = min(s["lifesteal"], caps["lifesteal"])
    for key in ("penetration", "ability_penetration", "basic_penetration"):
        s[key] = min(s[key], caps["penetration"])
    s["wasted_attack_speed"] = max(0.0, raw_as - caps["attack_speed"])
    return dict(s), effects


def evaluate(db: Database, god: God, items: list[Item], ctx: Context) -> Evaluation:
    mech = db.mechanics
    kit = god.kit
    target = mech["targets"][ctx.target]
    s, effects = aggregate_stats(db, god, items, ctx.stacks)
    STR, INT = s.get("strength", 0.0), s.get("intelligence", 0.0)

    # --- target protections after shred --------------------------------------
    prot_type = f"{god.damage_type}_protection"
    prot = float(target[prot_type])
    basic_reliance = min(1.0, kit["basic_uptime"] / 0.6)
    for e in effects:
        if e["kind"] != "target_prot_reduction":
            continue
        if e["protection"] not in (god.damage_type, "both"):
            continue
        up = _uptime(e) * (basic_reliance if e.get("requires") == "basic" else 1.0)
        prot *= 1 - e.get("value", 0.0) * up
        prot -= e.get("flat", 0.0) * up
    prot = max(prot, 0.0)

    def mitigation(pen: float) -> float:
        eff = max(0.0, prot * (1 - pen) - s.get("flat_penetration", 0.0))
        return 100.0 / (100.0 + eff)

    pen = s.get("penetration", 0.0)
    cap = mech["caps"]["penetration"]
    # some passives (Dominance, Titan's Bane) grant penetration that ignores the cap
    mit_ability = mitigation(min(1.0, min(cap, pen + s.get("ability_penetration", 0.0))
                                 + s.get("uncapped_ability_penetration", 0.0)))
    mit_basic = mitigation(min(1.0, min(cap, pen + s.get("basic_penetration", 0.0))
                               + s.get("uncapped_basic_penetration", 0.0)))

    # --- multipliers ---------------------------------------------------------
    # Echo: chance (in points) for an ability to Echo for +15% damage (wiki Stats page)
    ability_mult = 1 + s.get("echo", 0.0) / 100 * mech["damage"].get("echo_bonus", 0.15)
    basic_mult = 1.0
    for e in effects:
        if e["kind"] == "damage_mult":
            m = 1 + e["value"] * _uptime(e)
            if e["applies"] in ("ability", "all"):
                ability_mult *= m
            if e["applies"] in ("basic", "all"):
                basic_mult *= m

    crit_mult = mech["damage"]["base_crit_damage"] + s.get("crit_damage", 0.0)
    crit_factor = 1 + s.get("crit_chance", 0.0) * (crit_mult - 1)

    basic_hit = (god.base["basic_attack_base"]
                 + STR * mech["damage"]["basic_attack_strength_ratio"]
                 + INT * mech["damage"]["basic_attack_intelligence_ratio"]
                 + s.get("basic_damage", 0.0))
    combo_raw = (kit["combo_base"] + kit["combo_strength"] * STR + kit["combo_intelligence"] * INT
                 + kit.get("combo_protections", 0.0) * (s["physical_protection"] + s["magical_protection"])
                 + kit.get("combo_item_protections", 0.0) * s["item_protections"])

    cd_eff = kit["rotation_cooldown"] / (1 + s.get("cooldown_rate", 0.0)) * (1 - s.get("cooldown_haste", 0.0))
    attacks_per_sec = s["attack_speed_total"] * kit["basic_uptime"]
    n_ba = kit["basic_attacks_in_combo"]

    # Teamfights: area / bounce / pierce damage also hits nearby enemies. Extra targets count at a
    # reduced weight (they are not the focus target). Joust/Assault override the average in game_modes.
    sc = mech["scenario"]
    gm = mech.get("game_modes", {}).get(ctx.game_mode, {})
    avg_extra = gm.get("teamfight_extra_targets", sc.get("teamfight_extra_targets", 1.5))
    extra_w = sc.get("extra_target_weight", 0.5)

    def aoe_mult(extra) -> float:
        return 1 + extra_w * min(extra or 0, avg_extra)

    pierce = aoe_mult(kit.get("basic_extra_targets", 0))

    def proc_damage(e: dict) -> float:
        return (e.get("base", 0.0) + e.get("strength", 0.0) * STR + e.get("intelligence", 0.0) * INT
                + e.get("target_max_hp_pct", 0.0) * target["health"]
                + e.get("target_base_hp_pct", 0.0) * (target["health"] - target["item_health"])
                + e.get("target_item_hp_pct", 0.0) * target["item_health"]
                + e.get("max_health_pct", 0.0) * s["max_health"]
                + e.get("basic_hit_pct", 0.0) * basic_hit
                + e.get("target_max_hp_pct_per_strength", 0.0) * STR * target["health"]
                + e.get("target_current_hp_pct", 0.0) * 0.7 * target["health"]  # assume target at ~70%
                + e.get("item_protections", 0.0) * s["item_protections"]
                + e.get("basic_damage", 0.0) * s.get("basic_damage", 0.0))

    proc_burst = {"ability": 0.0, "basic": 0.0, "time": 0.0}
    proc_dps = {"ability": 0.0, "basic": 0.0, "time": 0.0}
    for e in effects:
        if e["kind"] != "proc":
            continue
        dmg = proc_damage(e) * _uptime(e) * aoe_mult(e.get("extra_targets", 0))
        on = e["applies_on"]
        if on == "basic":
            dmg *= pierce  # on-hit effects apply to every god a piercing attack hits
        if on == "ability":
            per_combo = e.get("per_combo", 1)
            if per_combo == "abilities":
                per_combo = kit["abilities_in_combo"]
            needs_basic = e.get("requires") == "basic" or "basic_hit_pct" in e
            if needs_basic:
                per_combo = min(per_combo, n_ba)
            rate = per_combo / cd_eff
            if e.get("cooldown", 0) > 0:
                rate = min(rate, 1.0 / e["cooldown"])
            if needs_basic:
                rate = min(rate, attacks_per_sec)
            proc_burst["ability"] += dmg * per_combo
            proc_dps["ability"] += dmg * rate
        elif on == "basic":
            every = e.get("every_n", 1)
            proc_burst["basic"] += dmg * n_ba / every
            proc_dps["basic"] += dmg * attacks_per_sec / every
        elif on == "echo":
            # triggers when an ability Echoes (chance = Echo points / 100), optionally every N Echoes
            echo_chance = s.get("echo", 0.0) / 100
            per_combo = kit["abilities_in_combo"] * echo_chance / e.get("every_n", 1)
            rate = per_combo / cd_eff
            if e.get("cooldown", 0) > 0:
                rate = min(rate, 1.0 / e["cooldown"])
            proc_burst["ability"] += dmg * per_combo
            proc_dps["ability"] += dmg * rate
        else:  # time: damage per second while in combat
            proc_burst["time"] += dmg * 3.0
            proc_dps["time"] += dmg

    burst_ability = (combo_raw + proc_burst["ability"]) * ability_mult * mit_ability
    burst_basic = (n_ba * basic_hit * crit_factor * pierce + proc_burst["basic"]) * basic_mult * mit_basic
    burst_time = proc_burst["time"] * mit_ability
    burst = burst_ability + burst_basic + burst_time

    dps_ability = (combo_raw / cd_eff + proc_dps["ability"]) * ability_mult * mit_ability
    dps_basic = (attacks_per_sec * basic_hit * crit_factor * pierce + proc_dps["basic"]) * basic_mult * mit_basic
    dps_time = proc_dps["time"] * mit_ability
    dps = dps_ability + dps_basic + dps_time

    # --- survivability -------------------------------------------------------
    hp = s["max_health"]
    for e in effects:
        if e["kind"] == "shield":
            hp += (e.get("base", 0.0) + e.get("max_health_pct", 0.0) * s["max_health"]
                   + e.get("strength_item", 0.0) * STR + e.get("intelligence_item", 0.0) * INT) * _uptime(e)
    keep_p = keep_m = 1.0
    for e in effects:
        if e["kind"] == "damage_reduction":
            m = 1 - e["value"] * _uptime(e)
            if e["damage"] in ("physical", "all"):
                keep_p *= m
            if e["damage"] in ("magical", "all"):
                keep_m *= m
    ehp_p = hp * (1 + s["physical_protection"] / 100) / keep_p
    ehp_m = hp * (1 + s["magical_protection"] / 100) / keep_m
    sp = ctx.enemy_physical_share
    ehp = 1.0 / (sp / ehp_p + (1 - sp) / ehp_m)
    # Plating (vs Attacks) and Dampening (vs Abilities): 1 point = 1% less of that damage, cap 35 each
    attack_share = mech["scenario"].get("enemy_attack_damage_share", 0.35)
    taken = 1 - (attack_share * s.get("plating", 0.0) + (1 - attack_share) * s.get("dampening", 0.0)) / 100
    ehp /= taken
    window = ctx.sustain_window or mech["scenario"]["sustained_window_seconds"]
    healing = s.get("lifesteal", 0.0) * (dps_basic + dps_ability / 3) + s.get("hp5", 0.0) / 5
    fight_ehp = ehp + healing * window

    utility = set(god.builtin_utility).union(*(it.utility_tags for it in items))
    mana_ok = s["max_mana"] >= 2 * kit["mana_per_rotation"]

    return Evaluation(
        stats=s, burst=burst, dps=dps, ehp=fight_ehp, utility=utility,
        breakdown={
            "target_protection_after_shred": round(prot, 1),
            "mitigation_ability": round(mit_ability, 3),
            "mitigation_basic": round(mit_basic, 3),
            "crit_factor": round(crit_factor, 3),
            "ability_mult": round(ability_mult, 3),
            "basic_mult": round(basic_mult, 3),
            "basic_hit_raw": round(basic_hit, 1),
            "combo_raw": round(combo_raw, 1),
            "effective_rotation_cd": round(cd_eff, 2),
            "burst_parts": {"abilities": round(burst_ability), "basics": round(burst_basic), "auras": round(burst_time)},
            "dps_parts": {"abilities": round(dps_ability), "basics": round(dps_basic), "auras": round(dps_time)},
            "ehp_physical": round(ehp_p), "ehp_magical": round(ehp_m),
            "healing_per_sec": round(healing, 1),
            "mana_ok": mana_ok,
        },
    )


def utility_factor(god: God, ev: Evaluation, ctx: Context) -> tuple[float, list[str]]:
    """Score multiplier for things the damage model can't see."""
    f, notes = 1.0, []
    if ctx.enemy_healing and "antiheal" not in ev.utility:
        f *= 1 - ctx.antiheal_penalty
        notes.append(f"no anti-heal vs healing comp (-{ctx.antiheal_penalty:.0%})")
    role = ctx.role or god.roles[0]
    if role == "Support":
        if "aura" in ev.utility:
            f *= 1.04
            notes.append("support aura (+4%)")
    gm_aura = ctx.aura_bonus
    if gm_aura and "aura" in ev.utility:
        f *= 1 + gm_aura
        notes.append(f"{ctx.game_mode} aura in cramped 3v3 fights (+{gm_aura:.0%})")
    # Effects outside the solo damage race (community builds value them; calibrated vs OB45-46 carry builds)
    if "kite" in ev.utility and god.attack_range == "ranged" and god.default_mode == "dps":
        f *= 1.04
        notes.append("attack while moving / kiting (+4%)")
    if "team_shred" in ev.utility:
        f *= 1.03
        notes.append("protection shred helps the whole team (+3%)")
    if role == "Jungle" and "jungle_clear" in ev.utility:
        f *= 1.03
        notes.append("jungle clear (+3%)")
    if ctx.enemy_cc_heavy and "cc_immunity" in ev.utility:
        f *= 1.05
        notes.append("CC immunity vs CC-heavy comp (+5%)")
    if "cooldown_reset" in ev.utility and god.kit["default_mode"] == "burst":
        f *= 1.02
        notes.append("kill/assist cooldown reset (+2%)")
    if not ev.breakdown["mana_ok"]:
        f *= 0.97
        notes.append("low mana pool for rotation (-3%)")
    return f, notes


class Scorer:
    """Scores builds relative to the god's item-less baseline so modes are comparable."""

    def __init__(self, db: Database, god: God, ctx: Context):
        self.db, self.god, self.ctx = db, god, ctx
        self.weights = mode_weights(god, ctx.mode)
        self.baseline = evaluate(db, god, [], ctx)
        self._cache: dict[frozenset, Evaluation] = {}

    def __call__(self, items: list[Item]) -> Evaluation:
        key = frozenset(i.name for i in items)
        if key in self._cache:
            return self._cache[key]
        ev = evaluate(self.db, self.god, items, self.ctx)
        b, w = self.baseline, self.weights
        log_score = (w["burst"] * math.log(ev.burst / b.burst)
                     + w["dps"] * math.log(ev.dps / b.dps)
                     + w["ehp"] * math.log(ev.ehp / b.ehp))
        factor, notes = utility_factor(self.god, ev, self.ctx)
        cdr = 1 - ev.breakdown["effective_rotation_cd"] / self.god.kit["rotation_cooldown"]
        log_score += UPTIME_WEIGHT[self.ctx.mode] * math.log(1 / (1 - min(cdr, 0.6)))
        ev.score = math.exp(log_score) * factor
        ev.breakdown["utility_notes"] = notes
        self._cache[key] = ev
        return ev
