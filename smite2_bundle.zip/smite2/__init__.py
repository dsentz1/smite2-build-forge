"""SMITE 2 loadout optimizer."""
