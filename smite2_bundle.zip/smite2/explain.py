"""Pros and cons of one item for one god, from the scoring model run across matchups.

The item is compared with the best alternative for the same slot in the god's optimal build, in each
scenario (target type, enemy damage type, enemy healing, snowball state). Mechanics come from the item's
wiki text and its modeled effects; anything the model does not score is listed so it can be weighed by hand.
"""
from dataclasses import replace

from .data import Database, God, Item
from .model import Context, Scorer
from .optimizer import Constraints, is_farm_stacking, optimize

SCENARIOS = [
    ("vs squishies", dict(target="squishy")),
    ("vs bruisers", dict(target="bruiser")),
    ("vs tanks", dict(target="tank")),
    ("vs mostly physical", dict(enemy_physical_share=0.8)),
    ("vs mostly magical", dict(enemy_physical_share=0.2)),
    ("vs healers", dict(enemy_healing=True)),
    ("behind (few stacks)", dict(stacks="behind")),
    ("ahead (full stacks)", dict(stacks="ahead")),
]

UTILITY_TEXT = {
    "antiheal": "applies anti-heal (40% cap, does not stack with a teammate's)",
    "aura": "aura for nearby allies", "team_sustain": "heals/shields or buffs allies",
    "kite": "attack while moving (kiting)", "team_shred": "its protection shred helps the whole team",
    "cooldown_reset": "cooldowns refresh on kills/assists", "cc_immunity": "crowd-control immunity",
    "stealth": "stealth/repositioning", "vision": "vision", "slow_immunity": "slow immunity",
    "anti_shield": "reduces enemy shields", "attack_speed_slow": "slows enemy attack speed",
    "soft_antiheal": "punishes enemy lifesteal", "sustain": "self-healing on kills", "gold_gain": "extra gold",
}


def _stacking(item: Item) -> list[str]:
    notes = []
    kinds = {e.get("snowball") for e in item.effects if e.get("snowball")}
    text = item.passive_text or ""
    if "farm" in kinds or is_farm_stacking(item):
        notes.append("stacks from farm/fights and evolves - buy it early, it is weak if bought late")
    if "kills" in kinds:
        notes.append("stacks from kills/assists - strong when ahead, weak when behind")
    if "combat" in kinds:
        notes.append("stacks during a fight - weaker in short trades")
    if "On Death: Lose" in text or "Lose" in text and "Death" in text:
        notes.append("loses stacks on death")
    return notes


def explain(db: Database, god: God, item: Item, ctx: Context, beam: int = 60) -> dict:
    base_build = optimize(db, god, ctx, Constraints([], set()), beam_width=beam, top=1)[0][0]
    with_item = optimize(db, god, ctx, Constraints([item] if item.tier == "t3" else [], set(),
                                                   starter=item if item.tier == "starter" else None),
                         beam_width=beam, top=1)[0][0]
    # the comparison build: the god's best build without this item
    without = optimize(db, god, ctx, Constraints([], {item.name}), beam_width=beam, top=1)[0][0]

    rows = []
    for label, kw in [("this matchup", {})] + SCENARIOS:
        c = replace(ctx, **kw)
        sc = Scorer(db, god, c)
        a, b = sc(with_item.all_items), sc(without.all_items)
        rows.append({"scenario": label, "score_vs_best_without": round(a.score / b.score - 1, 3),
                     "burst": round(a.burst / b.burst - 1, 3), "dps": round(a.dps / b.dps - 1, 3),
                     "ehp": round(a.ehp / b.ehp - 1, 3)})
    modeled = [e.get("note") or e["kind"] for e in item.effects if e["kind"] != "utility"]
    utility = [UTILITY_TEXT.get(t, t) for t in item.utility_tags]
    unmodeled = []
    if not item.effects and item.passive_text:
        unmodeled.append("its passive is not scored by the model - weigh it by hand")
    return {
        "item": item.name, "god": god.name, "cost": item.cost, "stats": item.stats,
        "passive": item.passive_text, "modeled_effects": modeled, "utility": utility,
        "stacking": _stacking(item), "not_scored": unmodeled,
        "in_optimal_build": item in base_build.all_items,
        "build_with_item": [i.name for i in with_item.all_items],
        "best_without_item": [i.name for i in without.all_items],
        "scenarios": rows,
    }


def format_explain(r: dict) -> str:
    out = [f"{r['item']} on {r['god']} — {r['cost']}g, stats {r['stats']}",
           f"  Passive: {r['passive'] or '-'}"]
    if r["modeled_effects"]:
        out.append("  Scored as: " + "; ".join(r["modeled_effects"]))
    if r["utility"]:
        out.append("  Utility (small score credit): " + "; ".join(r["utility"]))
    for n in r["stacking"]:
        out.append(f"  Stacking: {n}")
    for n in r["not_scored"]:
        out.append(f"  Not scored: {n}")
    out.append(f"  In the optimal build: {'yes' if r['in_optimal_build'] else 'no'}")
    out.append(f"  Best build with it:    {', '.join(r['build_with_item'])}")
    out.append(f"  Best build without it: {', '.join(r['best_without_item'])}")
    out.append("  Build with it vs best build without it (score / burst / DPS / EHP):")
    for s in r["scenarios"]:
        out.append(f"    {s['scenario']:22s} {s['score_vs_best_without']:+6.1%}   {s['burst']:+6.1%} / {s['dps']:+6.1%} / {s['ehp']:+6.1%}")
    rows = r["scenarios"][1:]
    best = max(rows, key=lambda s: s["score_vs_best_without"]); worst = min(rows, key=lambda s: s["score_vs_best_without"])
    out.append(f"  Strongest {best['scenario']} ({best['score_vs_best_without']:+.1%}); weakest {worst['scenario']} ({worst['score_vs_best_without']:+.1%}).")
    return "\n".join(out)
